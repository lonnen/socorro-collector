from datadog.dogstatsd.base import statsd  # noqa
